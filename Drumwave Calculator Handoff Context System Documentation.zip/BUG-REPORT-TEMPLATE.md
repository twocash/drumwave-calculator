# BUG REPORT TEMPLATE
## Use this to document bugs for next Claude session

---

## BUG METADATA

**Bug ID:** BUG-2025-001  
**Date Reported:** October 23, 2025  
**Severity:** 🔴 High / 🟡 Medium / 🟢 Low  
**Status:** New / In Progress / Fixed  
**Affects Version:** 2.1.1  

---

## BUG DESCRIPTION

### One-Line Summary
[Brief description - e.g., "Network metrics show incorrect values when selecting Low or High scenarios"]

### Detailed Description
[What's wrong? Be specific about what the user sees vs what they should see]

### Steps to Reproduce
1. Navigate to [view name]
2. Click/select [action]
3. Observe [what happens]

### Expected Behavior
[What should happen?]

### Actual Behavior
[What actually happens?]

### Screenshots
[Attach screenshots showing the bug]

---

## IMPACT ASSESSMENT

### User Impact
- [ ] Blocks critical functionality
- [ ] Shows incorrect data (data integrity issue)
- [ ] Visual/UX issue only
- [ ] Edge case (rare occurrence)

### Affected Views
- [ ] Executive Summary (DashboardView)
- [ ] Standalone Model (StandaloneView)
- [ ] Network Effects (NetworkView)
- [ ] Monthly Detail (MonthlyView)
- [ ] Details (DetailsView)

### Affected Scenarios
- [ ] Low scenario
- [ ] Base scenario
- [ ] High scenario
- [ ] Custom mode
- [ ] All scenarios

### Affected Features
- [ ] Walmart standalone calculations
- [ ] Network effects toggle
- [ ] Retailer configuration
- [ ] CSV export
- [ ] Charts/visualizations

---

## TECHNICAL ANALYSIS

### Probable Root Cause
[Your hypothesis about what's causing the bug]

### Suspected Code Location
**File:** src/App.jsx  
**Function:** [function name]  
**Line Range:** Lines XXX-YYY  
**Why:** [Why you think it's here]

### Related Code Sections
- [Other functions/areas that might be related]
- [Dependencies or calculations that feed into this]

### Data Flow Analysis
```
User Action: [what user did]
    ↓
State Changes: [what state variables changed]
    ↓
Calculations Triggered: [what useMemo recalculated]
    ↓
Affected Components: [what views re-rendered]
    ↓
Bug Manifests: [where incorrect data appears]
```

---

## DEBUGGING EVIDENCE

### Console Errors
```
[Paste any console errors here]
```

### Unexpected Values
```javascript
// Variable: expectedVariableName
// Expected: [value]
// Actual: [value]
// Location: Line XXX
```

### Logging Added
```javascript
// Add console.logs to verify:
console.log('assumptions:', assumptions);
console.log('fullNetworkResults:', fullNetworkResults);
console.log('displayValue:', displayValue);
```

---

## FIX APPROACH

### Option 1: [Approach Name]
**Description:** [What you'd do]  
**Pros:** [Benefits]  
**Cons:** [Drawbacks]  
**Risk:** Low / Medium / High  

### Option 2: [Alternative Approach]
**Description:** [What you'd do]  
**Pros:** [Benefits]  
**Cons:** [Drawbacks]  
**Risk:** Low / Medium / High  

### Recommended: [Which option and why]

---

## VERIFICATION PLAN

### Test Cases to Pass
1. [ ] Test case 1: [specific scenario]
2. [ ] Test case 2: [specific scenario]
3. [ ] Test case 3: [specific scenario]

### Regression Tests
- [ ] Verify Base scenario still works
- [ ] Verify all views still load
- [ ] Verify CSV export still works
- [ ] Check for new console errors

### Edge Cases to Check
- [ ] Edge case 1
- [ ] Edge case 2

---

## REFERENCE MATERIAL

### Related Documentation
- CODEBASE-CONTEXT.md (lines XXX-YYY)
- BUSINESS-LOGIC.md (section on [topic])
- Previous bug: BUG-XXXX (if related)

### External Resources
- [Links to relevant documentation]
- [Stack Overflow threads]
- [GitHub issues]

---

## FOR CLAUDE'S NEXT SESSION

### Context to Provide
1. ✅ This bug report (CURRENT-BUG.md)
2. ✅ CODEBASE-CONTEXT.md
3. ✅ Current src/App.jsx file
4. ✅ Screenshots showing the bug
5. ✅ [Any other relevant files]

### Starting Prompt
```
I have a bug in the DrumWave Calculator (React app).

Bug: [one-line summary]

Files provided:
- CURRENT-BUG.md (this bug report)
- CODEBASE-CONTEXT.md (complete architecture)
- src/App.jsx (current code)
- screenshots/ (visual evidence)

Please:
1. Read CURRENT-BUG.md thoroughly
2. Review suspected code location in App.jsx
3. Implement the recommended fix approach
4. Run all verification tests
5. Provide updated code + fix summary

This is production code. Data integrity is critical.
```

---

## NOTES

### Additional Context
[Any other information that might help]

### Workarounds
[Temporary workarounds users can use while bug is being fixed]

### Related Issues
[Link to other bugs that might be related]

---

**Created by:** [Your name]  
**Last Updated:** [Date]  
**Next Review:** [Date]
