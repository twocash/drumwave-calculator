# Quick Reference Card - DrumWave Calculator Context System

## 🚨 WHEN YOU HIT A BUG

### 1. Fill Out Bug Report (5 min)
```bash
cp BUG-REPORT-TEMPLATE.md CURRENT-BUG.md
# Fill in: Description, Steps, Suspected Location, Fix Approach, Tests
```

### 2. Gather Files
- ✅ CODEBASE-CONTEXT.md (architecture)
- ✅ CURRENT-BUG.md (your bug report)
- ✅ src/App.jsx (current code)
- ✅ Screenshots (if visual)

### 3. Start Fresh Claude Session

### 4. Upload in Order
1. CODEBASE-CONTEXT.md
2. CURRENT-BUG.md
3. src/App.jsx
4. Screenshots

### 5. Use This Prompt
```
Bug: [one-line summary from CURRENT-BUG.md]

Files provided:
- CODEBASE-CONTEXT.md (architecture)
- CURRENT-BUG.md (detailed report)
- src/App.jsx (code)

Please implement the recommended fix from CURRENT-BUG.md.
Test thoroughly. This is production code.
```

### 6. After Fix
```bash
# Test locally
npm run dev

# Deploy
git commit -am "Fix: [description]"
git push

# Archive
mv CURRENT-BUG.md archive/FIXED-BUG-XXX.md
```

---

## 📋 CURRENT STATUS

**Version:** 2.1.1  
**Last Updated:** October 23, 2025  
**Known Issues:** BUG-002 (Network scenarios)  
**In Progress:** [Your current task]

---

## 📁 FILE LOCATIONS

```
docs/
├── CODEBASE-CONTEXT.md     ← Read FIRST (architecture)
├── BUG-REPORT-TEMPLATE.md  ← Copy for each bug
├── CONTEXT-HANDOFF-SYSTEM.md ← Full instructions
├── CURRENT-BUG.md          ← What you're fixing NOW
└── archive/                ← Completed work
```

---

## 🎯 KEY LINE NUMBERS (src/App.jsx)

**Calculations:**
- Lines 7-11: Brand participation (sigmoid)
- Lines 14-107: Walmart standalone
- Lines 218-294: Retailer profiles
- Lines 368-434: Network calculations

**State Management:**
- Lines 465-530: All useState & useMemo

**Views:**
- Lines 532-698: Executive Summary
- Lines 700-918: Standalone View
- Lines 920-1264: Network View
- Lines 1266-1456: Monthly View
- Lines 1458-1641: Details View

---

## 🔧 COMMON FIXES

### Fix 1: Update Scenario
```javascript
// Location: Lines 169-215
const PRESETS = {
  NewScenario: {
    totalCustomers: 120000000,
    dwalletAdoption: 0.85,
    // ... all required fields
  }
};
```

### Fix 2: Add Retailer
```javascript
// Location: Lines 218-294
DEFAULT_RETAILERS.push({
  id: 'newretailer',
  name: 'New Retailer',
  totalCustomers: 50000000,
  launchMonth: 36,
  // ... all required fields
});
```

### Fix 3: Add Metric to Monthly View
```javascript
// Location: ~Line 1320
metrics.push({ 
  key: 'newMetric', 
  label: 'New Metric Name',
  format: (v) => formatCurrency(v),
  source: 'direct'
});
```

---

## ✅ PRE-DEPLOYMENT CHECKLIST

Before pushing to production:

- [ ] All scenarios work (Low/Base/High)
- [ ] Network effects toggle works
- [ ] No console errors
- [ ] No NaN values anywhere
- [ ] CSV export works
- [ ] Charts render correctly
- [ ] Test on Chrome, Firefox, Safari
- [ ] Verify mobile responsive

---

## 🐛 DEBUGGING COMMANDS

```javascript
// Add to src/App.jsx temporarily

// Check scenario switching:
console.log('Current scenario:', scenario);
console.log('Assumptions:', assumptions);

// Check network calculations:
console.log('fullNetworkResults:', fullNetworkResults[35]);
console.log('Network multiplier:', fullNetworkResults[35].networkMultiplier);

// Check retailer data:
console.log('networkRetailers:', networkRetailers);
console.log('Walmart retailer:', networkRetailers[0]);

// Check useMemo recalculation:
const results = useMemo(() => {
  console.log('🔄 Recalculating!');
  return calculateSomething();
}, [dependencies]);
```

---

## 🚀 DEPLOYMENT

```bash
# Local test
npm install
npm run dev
# Test at http://localhost:5173

# Deploy to production
git add .
git commit -m "Description"
git push origin main
# Vercel auto-deploys in 60 seconds
# URL: https://drumwave-calculator.vercel.app/
```

---

## 📊 EXPECTED VALUES (Base Scenario)

**Standalone (Walmart only, 36 months):**
- Revenue: $3.39B
- Consumer Earnings: $3.96B  
- EBIT per Customer: $50.47
- Active Certs (Mo 36): ~3B

**Network (3 Retailers):**
- Walmart Revenue: $4-5B
- Network Multiplier: ~1.05×
- Total Network Revenue: ~$30-40B
- Walmart Share: 10-15%

---

## 📞 NEED HELP?

**Check these first:**
1. CONTEXT-HANDOFF-SYSTEM.md (full guide)
2. CODEBASE-CONTEXT.md (architecture)
3. CURRENT-BUG.md (your specific issue)

**Still stuck?**
- Review "Common Pitfalls" (CODEBASE-CONTEXT.md Line 467)
- Check archived fixes (docs/archive/)
- Re-read fix approach in CURRENT-BUG.md

---

## 💡 PRO TIPS

1. **Always use the template** - Saves 15 minutes per bug
2. **Include line numbers** - Claude finds issues faster
3. **Propose a fix** - 3× faster than "please debug"
4. **Test thoroughly** - Production code, no shortcuts
5. **Update CODEBASE-CONTEXT.md** - Only after big changes
6. **Archive completed work** - Keep docs/ clean

---

## ⚡ SPEED COMMANDS

```bash
# Quick bug report
cp BUG-REPORT-TEMPLATE.md CURRENT-BUG.md && code CURRENT-BUG.md

# Quick test
npm run dev

# Quick deploy
git add . && git commit -m "Fix: [issue]" && git push

# Quick archive
mv CURRENT-BUG.md archive/FIXED-BUG-$(date +%Y%m%d).md
```

---

## 🎓 REMEMBER

**The Three Documents:**
1. **CODEBASE-CONTEXT.md** - Where is everything?
2. **CURRENT-BUG.md** - What needs fixing?
3. **CONTEXT-HANDOFF-SYSTEM.md** - How does it work?

**The Pattern:**
Fill out bug report → Upload to Claude → Get fix → Test → Deploy → Archive

**The Goal:**
30-minute bug fixes instead of 2-hour debugging sessions.

---

**Print this card. Keep it handy. Reference it often.**

Last Updated: October 23, 2025
