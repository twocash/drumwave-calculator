# DrumWave Calculator - Context Handoff System
## How to Efficiently Continue Work Across Claude Sessions

---

## THE PROBLEM

When working on a large codebase across multiple Claude sessions, you need to:
1. **Preserve what was built** (architecture, functions, patterns)
2. **Document current issues** (bugs, incomplete features)
3. **Provide clear context** for the next session to be productive
4. **Avoid re-explaining** the same information repeatedly

Traditional approaches fail because they create walls of text that exceed token limits.

---

## THE SOLUTION: Layered Context Documents

### Layer 1: Architecture (CODEBASE-CONTEXT.md)
**Purpose:** Permanent reference document  
**When to create:** After major milestones  
**Update frequency:** When architecture changes  
**Size target:** 5-10KB  

**Contains:**
- File structure
- Function locations (line numbers)
- Key algorithms
- Data structures
- Design patterns
- Common pitfalls

**Think of it as:** The codebase manual that rarely changes

---

### Layer 2: Current Issue (CURRENT-BUG.md or CURRENT-TASK.md)
**Purpose:** Specific problem to solve  
**When to create:** Each time you need help  
**Update frequency:** Every session  
**Size target:** 3-5KB  

**Contains:**
- What's broken (or needs building)
- Why it matters
- Where the problem likely is (line numbers)
- Proposed solution approach
- Test cases to verify fix

**Think of it as:** Today's work order

---

### Layer 3: Handoff Guide (THIS DOCUMENT)
**Purpose:** Instructions for using the other documents  
**When to create:** Once, then reference  
**Update frequency:** Rarely  
**Size target:** 2-3KB  

**Contains:**
- How the system works
- What to upload to Claude
- What prompt to use
- How to create new bug reports

**Think of it as:** The instruction manual for the instruction manuals

---

## HOW TO USE THIS SYSTEM

### Scenario 1: You Have a Bug

**Step 1: Copy the Bug Report Template**
- Use: `BUG-REPORT-TEMPLATE.md`
- Fill in all sections (especially: Description, Steps to Reproduce, Fix Approach)
- Save as: `CURRENT-BUG.md`

**Step 2: Gather Files**
- CURRENT-BUG.md (your filled-out bug report)
- CODEBASE-CONTEXT.md (architecture reference)
- src/App.jsx (current code)
- Screenshots (if visual bug)

**Step 3: Start New Claude Session**

**Step 4: Upload Files**
Upload in this order:
1. CODEBASE-CONTEXT.md
2. CURRENT-BUG.md  
3. src/App.jsx
4. Screenshots (if any)

**Step 5: Use This Prompt**
```
I have a bug in the DrumWave Calculator (React app).

Bug: [copy one-line summary from CURRENT-BUG.md]

Files provided:
- CODEBASE-CONTEXT.md (architecture reference)
- CURRENT-BUG.md (detailed bug report with fix approach)
- src/App.jsx (current code)
- [screenshots if applicable]

Please:
1. Read CURRENT-BUG.md thoroughly
2. Review the suspected code location
3. Implement the recommended fix approach
4. Run all verification tests
5. Provide updated code + fix summary

This is production code. Test thoroughly.
```

**Step 6: Claude Fixes Bug**
- Claude reads context
- Implements fix
- Tests thoroughly
- Provides updated code

**Step 7: Deploy & Update Docs**
- Test locally
- Deploy to Vercel
- Update CODEBASE-CONTEXT.md if architecture changed
- Archive CURRENT-BUG.md as FIXED-BUG-XXX.md

---

### Scenario 2: You Want to Add a Feature

**Step 1: Create Feature Request**
- Use similar structure to bug report
- Focus on: What you want, Why you want it, How it should work
- Save as: `CURRENT-TASK.md`

**Step 2: Same Process**
- Follow steps 2-7 from Scenario 1
- Replace "CURRENT-BUG.md" with "CURRENT-TASK.md"
- Adjust prompt accordingly

---

### Scenario 3: You Need to Understand the Code

**Step 1: Just Upload Architecture Doc**
- Upload: CODEBASE-CONTEXT.md
- Upload: src/App.jsx

**Step 2: Ask Specific Questions**
```
I'm trying to understand how [specific feature] works in the DrumWave Calculator.

Files provided:
- CODEBASE-CONTEXT.md (architecture reference)
- src/App.jsx (current code)

Please explain:
1. [Your specific question]
2. [Another question]

Point me to specific line numbers and function names.
```

---

## WHAT MAKES A GOOD BUG REPORT

### ✅ GOOD Example

```markdown
## BUG DESCRIPTION
Network metrics show incorrect values when selecting "Low" or "High" scenarios

## STEPS TO REPRODUCE
1. Go to Executive Summary
2. Check "Show Network Effects"
3. Select "Low" scenario
4. Observe: Walmart Revenue doesn't decrease (should be ~$2.5B, shows $5B)

## SUSPECTED CODE
**File:** src/App.jsx
**Lines:** 485-495 (fullNetworkResults useMemo)
**Why:** useMemo dependencies don't include full assumptions object

## FIX APPROACH
Add scenarioAdjustedRetailers to merge scenario assumptions with retailer profiles.
[Specific code snippet provided]
```

**Why this is good:**
- Specific values (expected vs actual)
- Exact steps to reproduce
- Line numbers provided
- Proposed solution with code
- Can be implemented in 30 minutes

---

### ❌ BAD Example

```markdown
## BUG DESCRIPTION
Network stuff is broken

## STEPS TO REPRODUCE  
Click on things and numbers are wrong

## FIX APPROACH
Fix the calculations
```

**Why this is bad:**
- Vague ("network stuff", "numbers")
- No specific steps
- No line numbers
- No proposed solution
- Claude would spend 30 minutes just diagnosing

---

## DOCUMENT MAINTENANCE

### When to Update CODEBASE-CONTEXT.md

**Update when:**
- ✅ Major function added/removed
- ✅ Architecture changes
- ✅ New calculation logic
- ✅ New view components
- ✅ Performance patterns change

**Don't update for:**
- ❌ Bug fixes (unless they change architecture)
- ❌ UI tweaks
- ❌ Minor variable renames
- ❌ Comment additions

**How to update:**
1. Open current CODEBASE-CONTEXT.md
2. Update relevant sections (line numbers, function descriptions)
3. Add new sections if needed
4. Keep it under 10KB
5. Test: Can someone understand the codebase from this doc alone?

### When to Create New Bug Report

**Create new report for:**
- Each distinct bug
- Each new feature request
- Each refactoring task

**Don't create for:**
- Follow-up questions on same bug
- Clarifications
- Documentation-only changes

### How to Archive Completed Work

**After fixing a bug:**
```bash
# Rename bug report
mv CURRENT-BUG.md archive/FIXED-BUG-002-network-scenarios.md

# Add entry to fix log
echo "BUG-002: Fixed network scenario switching (Oct 23, 2025)" >> FIXES-LOG.md
```

**After adding feature:**
```bash
mv CURRENT-TASK.md archive/COMPLETED-monthly-view.md
echo "FEATURE: Added Monthly Detail View (Oct 23, 2025)" >> FEATURES-LOG.md
```

---

## OPTIMAL DOCUMENT SIZES

### CODEBASE-CONTEXT.md
**Target:** 5-10KB (750-1500 lines)  
**Max:** 15KB before splitting  
**Contains:** Permanent architecture info  

**If it exceeds 15KB, split into:**
- CODEBASE-CONTEXT.md (architecture + key patterns)
- BUSINESS-LOGIC.md (financial formulas)
- API-REFERENCE.md (function signatures)

### CURRENT-BUG.md
**Target:** 3-5KB (450-750 lines)  
**Max:** 8KB  
**Contains:** One specific issue  

**If it exceeds 8KB:**
- Split into multiple bug reports
- Create "BUG-PARENT.md" linking to children

### Total Upload Size (per session)
**Target:** 10-15KB of documentation  
**Max:** 25KB  
**Leaves:** 165KB for code files and conversation

---

## EXAMPLE FILE ORGANIZATION

```
drumwave-calculator/
├── src/
│   └── App.jsx (current code)
├── docs/
│   ├── CODEBASE-CONTEXT.md (main architecture doc)
│   ├── BUG-REPORT-TEMPLATE.md (template)
│   ├── CONTEXT-HANDOFF-SYSTEM.md (this file)
│   ├── CURRENT-BUG.md (what you're working on now)
│   ├── FIXES-LOG.md (history of fixes)
│   ├── FEATURES-LOG.md (history of features)
│   └── archive/
│       ├── FIXED-BUG-001-nan-values.md
│       ├── FIXED-BUG-002-network-scenarios.md
│       └── COMPLETED-monthly-view.md
```

---

## PROMPTS LIBRARY

### Prompt 1: Fix a Bug
```
I have a bug in [app name].

Bug: [one-line summary]

Files: CODEBASE-CONTEXT.md, CURRENT-BUG.md, src/[file].jsx

Please:
1. Read bug report thoroughly
2. Implement recommended fix
3. Run verification tests
4. Provide updated code

This is production code.
```

### Prompt 2: Add a Feature
```
I need to add a feature to [app name].

Feature: [one-line summary]

Files: CODEBASE-CONTEXT.md, CURRENT-TASK.md, src/[file].jsx

Please:
1. Read task description
2. Follow architectural patterns from CODEBASE-CONTEXT.md
3. Implement feature
4. Add tests
5. Update CODEBASE-CONTEXT.md with new patterns

This is production code.
```

### Prompt 3: Understand the Code
```
Help me understand [specific feature] in [app name].

Files: CODEBASE-CONTEXT.md, src/[file].jsx

Questions:
1. [Question 1]
2. [Question 2]

Provide line numbers and function names.
```

### Prompt 4: Refactor
```
I need to refactor [specific component] in [app name].

Goal: [why you're refactoring]

Files: CODEBASE-CONTEXT.md, REFACTOR-PLAN.md, src/[file].jsx

Please:
1. Review current implementation
2. Implement refactor plan
3. Verify all tests pass
4. Update CODEBASE-CONTEXT.md

Preserve all existing functionality.
```

---

## SUCCESS METRICS

**You know this system is working when:**

1. **Fast Onboarding**
   - Claude understands context in <5 minutes
   - No time wasted on "what is this app?"
   - Jumps straight to solving the problem

2. **Accurate Fixes**
   - Bugs are fixed correctly first time
   - No regression issues
   - All test cases pass

3. **Minimal Back-and-Forth**
   - One prompt → one complete fix
   - No need for clarifying questions
   - Claude has all info needed

4. **Documentation Stays Current**
   - CODEBASE-CONTEXT.md reflects reality
   - Bug reports are detailed enough
   - Easy to pick up work later

5. **Low Maintenance Overhead**
   - Updating docs takes <10 minutes
   - Templates make bug reporting easy
   - Archive keeps history organized

---

## COMMON MISTAKES TO AVOID

### ❌ Mistake 1: Documentation Too Detailed
**Problem:** 50KB document that's never read  
**Solution:** Target 5-10KB, link to code for details

### ❌ Mistake 2: Vague Bug Reports
**Problem:** "Something's broken"  
**Solution:** Use template, provide specifics

### ❌ Mistake 3: Outdated Architecture Docs
**Problem:** Line numbers wrong, functions renamed  
**Solution:** Update after major changes only

### ❌ Mistake 4: No Test Cases
**Problem:** Can't verify fix works  
**Solution:** Always include verification steps

### ❌ Mistake 5: Multiple Bugs in One Report
**Problem:** Claude fixes one, misses others  
**Solution:** One report per bug

---

## QUICK START CHECKLIST

Setting up this system for a new project:

- [ ] Create CODEBASE-CONTEXT.md (use provided template)
- [ ] Create BUG-REPORT-TEMPLATE.md (copy from this project)
- [ ] Create CONTEXT-HANDOFF-SYSTEM.md (copy this file)
- [ ] Create docs/ folder structure
- [ ] Add to .gitignore: `docs/CURRENT-*.md` (work in progress)
- [ ] Don't ignore: `docs/archive/` (history)

Using the system for a bug:

- [ ] Copy BUG-REPORT-TEMPLATE.md → CURRENT-BUG.md
- [ ] Fill out all sections completely
- [ ] Gather code files
- [ ] Start new Claude session
- [ ] Upload documents + code
- [ ] Use provided prompt
- [ ] Test fix thoroughly
- [ ] Archive bug report
- [ ] Update architecture doc if needed

---

## REAL-WORLD EXAMPLE

**Context:** You just deployed Network Effects V2. Bug discovered: Low/High scenarios don't work.

**What you have:**
- CODEBASE-CONTEXT.md (from previous session)
- Working code (src/App.jsx version 2.1.1)
- Screenshots showing the bug

**What you do:**

**1. Fill out bug report (5 minutes)**
```bash
cp docs/BUG-REPORT-TEMPLATE.md docs/CURRENT-BUG.md
# Edit CURRENT-BUG.md:
# - Describe bug
# - Steps to reproduce
# - Suspected location: Line 485-495
# - Proposed fix: Option 1
# - Test cases
```

**2. Start new Claude session**

**3. Upload files (30 seconds)**
- CODEBASE-CONTEXT.md
- CURRENT-BUG.md
- src/App.jsx
- Screenshots

**4. Use prompt (10 seconds)**
```
Bug: Network metrics incorrect for Low/High scenarios

Files: CODEBASE-CONTEXT.md, CURRENT-BUG.md, App.jsx, screenshots

Please implement Option 1 from CURRENT-BUG.md.
Test thoroughly. This is production code.
```

**5. Claude fixes (15 minutes)**
- Reads context
- Implements scenarioAdjustedRetailers
- Runs tests
- Provides updated code

**6. You deploy (5 minutes)**
```bash
# Test locally
npm run dev
# Verify all scenarios work
# Deploy
git add src/App.jsx
git commit -m "Fix: Network effects now work for Low/High scenarios"
git push
```

**7. Archive (2 minutes)**
```bash
mv docs/CURRENT-BUG.md docs/archive/FIXED-BUG-002-scenarios.md
echo "BUG-002: Fixed network scenario switching (Oct 23)" >> docs/FIXES-LOG.md
```

**Total time:** 35 minutes (vs 2+ hours without the system)

---

## CONCLUSION

**The key insight:** Break context into layers

1. **Permanent context** (CODEBASE-CONTEXT.md) - rarely changes
2. **Current problem** (CURRENT-BUG.md) - changes each session
3. **Instructions** (this document) - reference once

This keeps each document small, focused, and useful.

**Result:**
- Faster bug fixes
- Better code quality
- Lower context switching cost
- Easy to resume work later
- New team members onboard quickly

**Next time you need help:**
1. Check if CODEBASE-CONTEXT.md is current (update if not)
2. Fill out bug report template
3. Upload both + code
4. Use prompt from library
5. Done

Simple. Repeatable. Effective.

---

**Master these three files:**
1. CODEBASE-CONTEXT.md (where is everything?)
2. CURRENT-BUG.md (what needs fixing?)
3. This file (how to use the system?)

**Everything else follows.**

---

Created: October 23, 2025  
Version: 1.0  
For: DrumWave Calculator Project  
Works with: Claude 3.5+ (any context window size)
