# BUG REPORT: Network Effects Incorrect for Low/High Scenarios
## CURRENT-BUG.md

---

## BUG METADATA

**Bug ID:** BUG-2025-002  
**Date Reported:** October 23, 2025  
**Severity:** 🔴 High (Data Integrity Issue)  
**Status:** New  
**Affects Version:** 2.1.1 (Post Critical Fix)  

---

## BUG DESCRIPTION

### One-Line Summary
Network Effects metrics show incorrect values when selecting "Low" or "High" scenarios (only "Base" scenario works correctly)

### Detailed Description
When the user switches from "Base" scenario to either "Low" or "High" scenario while Network Effects are enabled, the displayed metrics become incorrect. The values appear to either:
- Not update from Base scenario values, OR
- Use wrong assumptions/parameters in calculations, OR
- Mix data from different scenarios

The bug only manifests when "Show Network Effects" is checked. Standalone mode works fine for all scenarios.

### Steps to Reproduce
1. Navigate to Executive Summary
2. Ensure "Show Network Effects" is **unchecked** (OFF)
3. Click "Base" scenario - note the Walmart Revenue (should be ~$3.39B)
4. Now **check** "Show Network Effects" and select "3 Retailers"
5. Walmart Revenue should increase to ~$4-5B ✓ (this works)
6. Now click "Low" scenario
7. Observe: Network metrics don't update correctly ✗
8. Try "High" scenario  
9. Observe: Network metrics incorrect ✗
10. Switch back to "Base" - numbers look correct again ✓

### Expected Behavior
- **Low Scenario + Network (3 retailers):** Walmart revenue should be ~$2.5-3.5B (lower than Base)
- **High Scenario + Network (3 retailers):** Walmart revenue should be ~$6-8B (higher than Base)
- All metrics should update smoothly when switching scenarios
- Network multiplier badge should remain consistent across scenarios

### Actual Behavior
[User to provide screenshots showing the incorrect values]

---

## IMPACT ASSESSMENT

### User Impact
- [x] Shows incorrect data (data integrity issue) **← CRITICAL**
- [x] Blocks critical functionality (can't demo Low/High scenarios)

### Affected Views
- [x] Executive Summary (DashboardView) - when Network Effects enabled
- [x] Network Effects (NetworkView) - all metrics
- [ ] Monthly Detail (MonthlyView) - TBD (need to verify)

### Affected Scenarios
- [x] Low scenario
- [ ] Base scenario (works correctly)
- [x] High scenario
- [ ] Custom mode (need to test)

### Affected Features
- [ ] Walmart standalone calculations (these work fine)
- [x] Network effects toggle (breaks on non-Base scenarios)
- [ ] Retailer configuration
- [ ] CSV export (probably reflects incorrect data)

---

## TECHNICAL ANALYSIS

### Probable Root Cause

**Hypothesis:** The `fullNetworkResults` calculation is not properly consuming the `assumptions` object when scenario changes.

**Why this might happen:**
1. **useMemo dependencies might be incomplete**
   - `fullNetworkResults` useMemo might not include all relevant dependencies
   - When scenario changes, assumptions change, but fullNetworkResults doesn't recalculate
   
2. **Retailer profiles override scenario assumptions**
   - DEFAULT_RETAILERS has hardcoded values (dwalletAdoption, annualTransactions, etc.)
   - These might override the scenario-specific assumptions
   - Base scenario happens to match DEFAULT_RETAILERS values (coincidentally works)
   - Low/High scenarios have different values but aren't applied to retailers

3. **calculateNetworkResults() doesn't use all assumptions**
   - Function signature: `calculateNetworkResults(retailers, mintingFee, licenseFee, usesPerCertPerYear, metcalfeCoefficient)`
   - Missing: dwalletAdoption, activeConsent, annualTransactions, brandStartPct, brandEndPct, etc.
   - These are embedded in retailer objects instead of passed as parameters

### Suspected Code Location

**Primary Suspect:** Lines 465-530 (State & useMemo calculations)

```javascript
// Line ~475 (approximate):
const assumptions = customMode && customAssumptions ? customAssumptions : PRESETS[scenario];

// Line ~485-495 (approximate):
const fullNetworkResults = useMemo(
  () => calculateNetworkResults(
    networkRetailers,  // ← Uses DEFAULT_RETAILERS which have fixed values
    assumptions.mintingFee, 
    assumptions.licenseFee, 
    assumptions.usesPerCertPerYear,
    metcalfeCoefficient
  ),
  [networkRetailers, assumptions.mintingFee, assumptions.licenseFee, 
   assumptions.usesPerCertPerYear, metcalfeCoefficient]
);
// ⚠️ Problem: Doesn't include assumptions.dwalletAdoption, annualTransactions, etc.
```

**Secondary Suspect:** Lines 218-294 (DEFAULT_RETAILERS)

```javascript
const DEFAULT_RETAILERS = [
  {
    id: 'walmart',
    name: 'Walmart',
    totalCustomers: 120000000,
    dwalletAdoption: 0.70,  // ← HARDCODED (Base scenario value)
    activeConsent: 0.80,    // ← HARDCODED
    annualTransactions: 65, // ← HARDCODED
    // ...
  },
  // ...
];
```

These hardcoded values match the **Base scenario** but not Low/High scenarios.

**Tertiary Suspect:** Lines 368-434 (calculateNetworkResults function)

The function doesn't receive enough parameters to apply scenario-specific assumptions.

### Related Code Sections

1. **calculateRetailerResultsV2** (Lines 305-365)
   - Uses retailer.dwalletAdoption, retailer.annualTransactions directly
   - Doesn't check if scenario assumptions should override these

2. **DashboardView network display** (Lines 532-698)
   - Consumes fullNetworkResults
   - Might be displaying cached/stale data

### Data Flow Analysis

```
User Action: Clicks "Low" scenario button
    ↓
State Changes: scenario state changes from 'Base' to 'Low'
    ↓
assumptions object changes: PRESETS['Low'] loaded
    ↓
singleRetailerResults recalculates: ✓ (works correctly)
    ↓
fullNetworkResults SHOULD recalculate but doesn't: ✗
    ↓
Why? useMemo dependencies don't include full assumptions object
    ↓
Bug Manifests: Old Base scenario numbers displayed
```

---

## DEBUGGING EVIDENCE

### Console Logs to Add

Add these to src/App.jsx around line 490:

```javascript
// After assumptions definition:
console.log('Current scenario:', scenario);
console.log('assumptions:', assumptions);

// Inside fullNetworkResults useMemo:
const fullNetworkResults = useMemo(() => {
  console.log('🔄 Recalculating fullNetworkResults');
  console.log('  networkRetailers:', networkRetailers);
  console.log('  mintingFee:', assumptions.mintingFee);
  console.log('  licenseFee:', assumptions.licenseFee);
  console.log('  usesPerCertPerYear:', assumptions.usesPerCertPerYear);
  console.log('  metcalfeCoefficient:', metcalfeCoefficient);
  
  return calculateNetworkResults(
    networkRetailers, 
    assumptions.mintingFee, 
    assumptions.licenseFee, 
    assumptions.usesPerCertPerYear,
    metcalfeCoefficient
  );
}, [networkRetailers, assumptions.mintingFee, assumptions.licenseFee, 
    assumptions.usesPerCertPerYear, metcalfeCoefficient]);

console.log('fullNetworkResults month 36:', fullNetworkResults[35]);
```

**Expected:** When switching scenarios, you should see "🔄 Recalculating fullNetworkResults"  
**If bug present:** You WON'T see the recalculation log

### Variables to Inspect

```javascript
// In Network View, check:
console.log('Scenario:', scenario);
console.log('Assumptions dwalletAdoption:', assumptions.dwalletAdoption);
console.log('Walmart retailer dwalletAdoption:', networkRetailers[0].dwalletAdoption);
console.log('Do they match?', assumptions.dwalletAdoption === (networkRetailers[0].dwalletAdoption * networkRetailers[0].activeConsent));

// Expected for Low: 0.28 (40% × 70%)
// Expected for Base: 0.56 (70% × 80%)  
// Expected for High: 0.765 (90% × 85%)
```

---

## FIX APPROACH

### Option 1: Apply Scenario to Retailers (RECOMMENDED)

**Description:** When scenario changes, update networkRetailers to use scenario assumptions

**Implementation:**
```javascript
// Around line 475, after assumptions definition:
const assumptions = customMode && customAssumptions ? customAssumptions : PRESETS[scenario];

// NEW: Apply scenario assumptions to retailers
const scenarioAdjustedRetailers = useMemo(() => {
  return networkRetailers.map(retailer => ({
    ...retailer,
    // Override with scenario-specific values (only for Walmart)
    ...(retailer.id === 'walmart' ? {
      totalCustomers: assumptions.totalCustomers,
      dwalletAdoption: assumptions.dwalletAdoption,
      activeConsent: assumptions.activeConsent,
      annualTransactions: assumptions.annualTransactions,
      brandStartPct: assumptions.brandStartPct,
      brandEndPct: assumptions.brandEndPct,
      monthsToFull: assumptions.monthsToFull,
      itemFloor: assumptions.itemFloor,
      itemCeiling: assumptions.itemCeiling
    } : {})
  }));
}, [networkRetailers, scenario, assumptions]);

// Then use scenarioAdjustedRetailers in fullNetworkResults:
const fullNetworkResults = useMemo(
  () => calculateNetworkResults(
    scenarioAdjustedRetailers,  // ← Use adjusted retailers
    assumptions.mintingFee, 
    assumptions.licenseFee, 
    assumptions.usesPerCertPerYear,
    metcalfeCoefficient
  ),
  [scenarioAdjustedRetailers, assumptions.mintingFee, assumptions.licenseFee, 
   assumptions.usesPerCertPerYear, metcalfeCoefficient]
);
```

**Pros:**
- Clean separation: scenarios affect Walmart, retailer config affects other retailers
- Minimal code changes
- Easy to understand

**Cons:**
- Creates intermediate data structure
- Slight performance overhead (negligible)

**Risk:** Low

---

### Option 2: Pass Full Assumptions to calculateNetworkResults

**Description:** Modify calculateNetworkResults() to accept full assumptions object

**Implementation:**
```javascript
// Modify function signature (Line 368):
function calculateNetworkResults(
  retailers, 
  assumptions,  // ← Pass entire object
  metcalfeCoefficient = 0.5
) {
  // Extract what we need:
  const { mintingFee, licenseFee, usesPerCertPerYear } = assumptions;
  
  // Apply scenario assumptions to Walmart retailer inside the loop
  const retailerMonthResults = retailers.map((retailer, idx) => {
    // If Walmart, merge scenario assumptions
    const effectiveRetailer = retailer.id === 'walmart' 
      ? { ...retailer, ...assumptions }
      : retailer;
    
    return calculateRetailerResultsV2(effectiveRetailer, month, ...);
  });
}

// Update useMemo (Line 485):
const fullNetworkResults = useMemo(
  () => calculateNetworkResults(
    networkRetailers,
    assumptions,  // ← Pass entire object
    metcalfeCoefficient
  ),
  [networkRetailers, assumptions, metcalfeCoefficient]  // ← Full object dependency
);
```

**Pros:**
- Cleaner function signature
- Full assumptions object dependency is explicit
- Works for custom mode automatically

**Cons:**
- Larger code change in calculateNetworkResults()
- Need to handle object merging carefully

**Risk:** Medium

---

### Option 3: Make Retailers Scenario-Aware

**Description:** Remove DEFAULT_RETAILERS state, generate dynamically from scenario

**Implementation:**
```javascript
// Remove DEFAULT_RETAILERS from state
// Generate retailers dynamically:
const networkRetailers = useMemo(() => {
  return [
    {
      id: 'walmart',
      name: 'Walmart',
      ...assumptions,  // ← Use scenario assumptions
      launchMonth: 0,
      color: '#0071CE'
    },
    {
      id: 'target',
      name: 'Target',
      totalCustomers: 75000000,
      dwalletAdoption: 0.65,
      // ... other retailers keep their values
    }
  ];
}, [assumptions]);
```

**Pros:**
- Elegant: retailers always use current scenario
- Removes state management complexity

**Cons:**
- Breaks retailer configuration UI (can't edit Walmart anymore)
- Major architectural change

**Risk:** High

---

### Recommended: Option 1 (Apply Scenario to Retailers)

**Why:**
- Lowest risk
- Preserves existing architecture
- Fixes the immediate bug
- Maintains retailer configuration feature
- Easy to understand and maintain

**Implementation Time:** 15 minutes  
**Testing Time:** 15 minutes  
**Total:** 30 minutes

---

## VERIFICATION PLAN

### Test Cases to Pass

1. **Low Scenario + Network**
   - [ ] Select "Low" scenario
   - [ ] Check "Show Network Effects", select "3 Retailers"
   - [ ] Verify Walmart Revenue is lower than Base (~$2-3B)
   - [ ] Verify Consumer Earnings is lower than Base
   - [ ] Verify Network multiplier is consistent (~1.05×)

2. **High Scenario + Network**
   - [ ] Select "High" scenario
   - [ ] Check "Show Network Effects", select "3 Retailers"
   - [ ] Verify Walmart Revenue is higher than Base (~$6-8B)
   - [ ] Verify Consumer Earnings is higher than Base
   - [ ] Verify Network multiplier is consistent (~1.05×)

3. **Scenario Switching**
   - [ ] Toggle between Low → Base → High multiple times
   - [ ] Verify numbers update each time
   - [ ] No console errors
   - [ ] No UI lag

4. **Network View Consistency**
   - [ ] Navigate to Network Effects tab
   - [ ] Switch scenarios
   - [ ] Verify all 5 retailers update (not just Walmart)
   - [ ] Verify aggregate totals are correct
   - [ ] Verify Walmart Share percentage makes sense

5. **Monthly Detail View**
   - [ ] Navigate to Monthly Detail
   - [ ] Switch scenarios
   - [ ] Verify all 36 months update
   - [ ] Export CSV - verify correct data

### Regression Tests
- [ ] Verify Base scenario still works perfectly
- [ ] Verify standalone mode (Network toggle OFF) works for all scenarios
- [ ] Verify retailer configuration still works
- [ ] Verify Metcalfe coefficient slider still works
- [ ] Check for any console errors
- [ ] Verify no NaN values anywhere

### Edge Cases to Check
- [ ] Custom mode + Network effects
- [ ] Switch scenario while retailer config panel open
- [ ] Change Metcalfe coefficient while switching scenarios
- [ ] Switch scenario rapidly (stress test)

---

## REFERENCE MATERIAL

### Related Documentation
- CODEBASE-CONTEXT.md (Lines 465-530: State Management)
- CODEBASE-CONTEXT.md (Lines 218-294: Retailer Profiles)
- CODEBASE-CONTEXT.md (Lines 368-434: calculateNetworkResults)

### Related Code Patterns
- See "How to Add a New Scenario" (CODEBASE-CONTEXT.md Line 556)
- See "Common Pitfalls" (CODEBASE-CONTEXT.md Line 467)

---

## FOR CLAUDE'S NEXT SESSION

### Context to Provide
1. ✅ This bug report (CURRENT-BUG.md)
2. ✅ CODEBASE-CONTEXT.md (architecture reference)
3. ✅ Current src/App.jsx file
4. ✅ Screenshots showing incorrect values (user to provide)
5. ✅ Console logs if available

### Starting Prompt
```
I have a bug in the DrumWave Calculator (React app).

Bug: Network Effects metrics show incorrect values for Low/High scenarios (only Base works)

Files provided:
- CURRENT-BUG.md (detailed bug report with fix approach)
- CODEBASE-CONTEXT.md (complete architecture)
- src/App.jsx (current code, version 2.1.1)
- screenshots/ (showing incorrect values)

Please implement Option 1 (Apply Scenario to Retailers):
1. Read CURRENT-BUG.md thoroughly - especially the Fix Approach section
2. Locate the code around Line 475 (state management)
3. Add scenarioAdjustedRetailers useMemo as described
4. Update fullNetworkResults to use scenarioAdjustedRetailers
5. Run all verification tests
6. Provide updated code + confirmation all tests pass

Expected outcome: All scenarios (Low/Base/High) work correctly with Network Effects enabled.

This is production code. Test thoroughly before delivering.
```

---

## NOTES

### Why This Bug Wasn't Caught Earlier
- Base scenario values match DEFAULT_RETAILERS values (56% adoption, 65 txn/year)
- All testing was done with Base scenario + Network Effects
- Low/High scenarios weren't tested with Network Effects enabled
- Standalone mode works fine (uses assumptions directly)

### Impact on Users
- Users can't demonstrate Low/High scenarios to stakeholders
- Data shown in presentations would be incorrect
- Undermines credibility of the model

### Workaround (Until Fixed)
- Use Base scenario for network effects demonstrations
- Manually explain how Low/High would differ
- Or toggle Network Effects OFF when using Low/High scenarios

---

**Created by:** Jim Calhoun  
**Date:** October 23, 2025  
**Status:** Ready for implementation  
**Estimated Fix Time:** 30 minutes
